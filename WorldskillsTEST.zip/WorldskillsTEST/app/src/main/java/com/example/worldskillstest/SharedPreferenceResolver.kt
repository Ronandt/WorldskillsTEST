package com.example.worldskillstest

import android.content.Context
import org.json.JSONObject

class SharedPreferenceResolver(context: Context) {
    var sharedPref = context.getSharedPreferences("Session", Context.MODE_PRIVATE)
    fun setUserSession(jsonObject: JSONObject) {
        with(sharedPref.edit()) {
            this.putString("session", jsonObject.toString())
            apply()
        }
    }
    fun getUserSession(): JSONObject? {
       return sharedPref.getString("session", JSONObject().toString())?.let { JSONObject(it) }
    }

    fun clearUserSession() {
        with(sharedPref.edit()) {
            this.remove("session")
            apply()
        }
    }
}